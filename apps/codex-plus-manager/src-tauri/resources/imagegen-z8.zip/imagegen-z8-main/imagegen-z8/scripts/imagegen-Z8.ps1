[CmdletBinding()]
param(
  [Parameter(ValueFromRemainingArguments = $true)]
  [string[]]$CliArgs
)
$ErrorActionPreference = 'Stop'
$skillRoot = Split-Path -Parent $PSScriptRoot
$architecture = $env:PROCESSOR_ARCHITEW6432
if ([string]::IsNullOrWhiteSpace($architecture)) { $architecture = $env:PROCESSOR_ARCHITECTURE }
switch ($architecture.ToUpperInvariant()) {
  'ARM64' { $target = 'windows-arm64' }
  'AMD64' { $target = 'windows-amd64' }
  default { throw 'imagegen-Z8 supports Windows x64 and ARM64. Use the matching release package.' }
}
$executable = Join-Path $skillRoot "bin\imagegen-Z8-$target.exe"
if (-not (Test-Path -LiteralPath $executable -PathType Leaf)) {
  throw "imagegen-Z8 executable is missing for $target. Reinstall the complete release package."
}
& $executable @CliArgs
exit $LASTEXITCODE
