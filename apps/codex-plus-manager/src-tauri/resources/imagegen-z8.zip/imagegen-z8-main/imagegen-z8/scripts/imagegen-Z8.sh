#!/bin/sh
set -eu
skill_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
case "$(uname -s)" in
  Darwin) platform=darwin ;;
  Linux) platform=linux ;;
  *) printf '%s\n' 'Unsupported platform. On Windows use scripts/imagegen-Z8.ps1.' >&2; exit 1 ;;
esac
case "$(uname -m)" in
  x86_64|amd64) architecture=amd64 ;;
  aarch64|arm64) architecture=arm64 ;;
  *) printf '%s\n' 'imagegen-Z8 supports x64 and ARM64.' >&2; exit 1 ;;
esac
executable="$skill_root/bin/imagegen-Z8-$platform-$architecture"
if [ ! -f "$executable" ]; then
  printf '%s\n' 'Missing imagegen-Z8 executable. Reinstall the complete release package.' >&2
  exit 1
fi
if [ ! -x "$executable" ]; then chmod u+x "$executable"; fi
exec "$executable" "$@"
