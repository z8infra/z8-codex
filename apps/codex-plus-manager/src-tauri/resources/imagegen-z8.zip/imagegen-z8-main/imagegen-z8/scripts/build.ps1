[CmdletBinding()]
param([string]$Go = 'go')
$ErrorActionPreference = 'Stop'
$skillRoot = Split-Path -Parent $PSScriptRoot
$binDir = Join-Path $skillRoot 'bin'
$previousGoos = $env:GOOS
$previousGoarch = $env:GOARCH
$previousCgo = $env:CGO_ENABLED
$previousToolchain = $env:GOTOOLCHAIN
Push-Location (Join-Path $skillRoot 'src')
try {
  New-Item -ItemType Directory -Path $binDir -Force | Out-Null
  $env:CGO_ENABLED = '0'
  $env:GOTOOLCHAIN = 'local'
  foreach ($platform in @('windows', 'darwin', 'linux')) {
    foreach ($architecture in @('amd64', 'arm64')) {
      $env:GOOS = $platform
      $env:GOARCH = $architecture
      $suffix = if ($platform -eq 'windows') { '.exe' } else { '' }
      $output = Join-Path $binDir "imagegen-Z8-$platform-$architecture$suffix"
      & $Go build -trimpath -buildvcs=false -ldflags '-s -w' -o $output .
      if ($LASTEXITCODE -ne 0) { throw "Build failed: $platform/$architecture" }
      Write-Output "Built $platform/$architecture"
    }
  }
  $checksums = Get-ChildItem -LiteralPath $binDir -File | Where-Object { $_.Name -like 'imagegen-Z8-*' } | Sort-Object Name | ForEach-Object {
    $hash = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    "$hash  $($_.Name)"
  }
  [IO.File]::WriteAllText((Join-Path $binDir 'SHA256SUMS'), (($checksums -join "`n") + "`n"), [Text.UTF8Encoding]::new($false))
} finally {
  $env:GOOS = $previousGoos
  $env:GOARCH = $previousGoarch
  $env:CGO_ENABLED = $previousCgo
  $env:GOTOOLCHAIN = $previousToolchain
  Pop-Location
}
