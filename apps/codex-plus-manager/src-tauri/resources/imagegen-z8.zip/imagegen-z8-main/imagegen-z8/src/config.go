package main

import (
	"bufio"
	"errors"
	"fmt"
	"net"
	"net/url"
	"os"
	"path/filepath"
	"strings"
)

const version = "1.0.0"
const defaultModel = "gpt-image-2"

// Credentials are intentionally unexported: JSON and diagnostic output never include them.
type config struct {
	Mode    string `json:"mode"`
	Source  string `json:"source"`
	BaseURL string `json:"base_url,omitempty"`
	Model   string `json:"model"`
	key     string
}

var configNames = []string{"IMAGEGEN_MODE", "IMAGEGEN_BASE_URL", "IMAGEGEN_API_KEY", "IMAGEGEN_MODEL", "IMAGEGEN_KEY_ID"}

func defaultConfigPath() (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", errors.New("cannot locate user home; use --config")
	}
	return filepath.Join(home, ".imagegen-Z8", ".env"), nil
}

// Parse data, never evaluate dotenv as shell code or expand variables.
func readDotEnv(path string) (map[string]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, errors.New("cannot open configuration file; run config-init or check --config")
	}
	defer f.Close()
	values := map[string]string{}
	scanner := bufio.NewScanner(f)
	scanner.Buffer(make([]byte, 4096), 65536)
	line := 0
	for scanner.Scan() {
		line++
		text := strings.TrimSpace(strings.TrimPrefix(scanner.Text(), "\ufeff"))
		if text == "" || strings.HasPrefix(text, "#") {
			continue
		}
		text = strings.TrimPrefix(text, "export ")
		name, value, ok := strings.Cut(text, "=")
		name, value = strings.TrimSpace(name), strings.TrimSpace(value)
		if !ok {
			return nil, fmt.Errorf("invalid configuration syntax at line %d (values hidden)", line)
		}
		known := false
		for _, allowed := range configNames {
			if name == allowed {
				known = true
				break
			}
		}
		if !known {
			return nil, fmt.Errorf("unknown configuration field at line %d (values hidden)", line)
		}
		if _, exists := values[name]; exists {
			return nil, fmt.Errorf("duplicate configuration field at line %d", line)
		}
		if strings.HasPrefix(value, "\"") || strings.HasPrefix(value, "'") {
			quote := value[0]
			end := strings.IndexByte(value[1:], quote)
			if end < 0 {
				return nil, fmt.Errorf("unclosed quote at line %d", line)
			}
			end++
			tail := strings.TrimSpace(value[end+1:])
			if tail != "" && !strings.HasPrefix(tail, "#") {
				return nil, fmt.Errorf("invalid quoted value at line %d", line)
			}
			value = value[1:end]
		} else if pos := strings.Index(value, " #"); pos >= 0 {
			value = strings.TrimSpace(value[:pos])
		}
		values[name] = value
	}
	if scanner.Err() != nil {
		return nil, errors.New("cannot read configuration: invalid or oversized line")
	}
	return values, nil
}

func loadConfig(explicit string, offline bool) (config, error) {
	var values map[string]string
	var err error
	source := ""
	if explicit == "" {
		explicit = strings.TrimSpace(os.Getenv("IMAGEGEN_CONFIG"))
	}
	if explicit != "" {
		values, err = readDotEnv(explicit)
		source, _ = filepath.Abs(explicit)
	} else {
		values = map[string]string{}
		for _, name := range configNames {
			if value, present := os.LookupEnv(name); present {
				values[name] = value
			}
		}
		if len(values) > 0 {
			source = "process environment"
		} else {
			path, pathErr := defaultConfigPath()
			if pathErr != nil {
				return config{}, pathErr
			}
			source = path
			if _, statErr := os.Stat(path); offline && os.IsNotExist(statErr) {
				values = map[string]string{}
			} else {
				values, err = readDotEnv(path)
			}
		}
	}
	if err != nil {
		return config{}, err
	}
	c := config{Mode: strings.TrimSpace(values["IMAGEGEN_MODE"]), Source: source, BaseURL: strings.TrimSpace(values["IMAGEGEN_BASE_URL"]), Model: strings.TrimSpace(values["IMAGEGEN_MODEL"]), key: strings.TrimSpace(values["IMAGEGEN_API_KEY"])}
	if c.Mode == "" {
		c.Mode = "direct"
	}
	if c.Mode == "z8" {
		return config{}, errors.New("z8 managed mode is reserved for the future integration; version 1 supports IMAGEGEN_MODE=direct only")
	}
	if c.Mode != "direct" {
		return config{}, errors.New("IMAGEGEN_MODE must be direct")
	}
	if values["IMAGEGEN_KEY_ID"] != "" {
		return config{}, errors.New("IMAGEGEN_KEY_ID is for future managed mode; configure a direct API key for version 1")
	}
	if c.Model == "" {
		c.Model = defaultModel
	}
	if len(c.Model) > 256 || strings.ContainsAny(c.Model, "\r\n\x00") {
		return config{}, errors.New("invalid model identifier")
	}
	if c.BaseURL != "" {
		c.BaseURL, err = normalizeBase(c.BaseURL)
		if err != nil {
			return config{}, err
		}
	}
	if strings.ContainsAny(c.key, "\r\n\x00") || len(c.key) > 4096 {
		return config{}, errors.New("invalid IMAGEGEN_API_KEY format (value hidden)")
	}
	if !offline {
		if c.BaseURL == "" {
			return config{}, errors.New("IMAGEGEN_BASE_URL is missing; configure it locally")
		}
		if c.key == "" || c.key == "replace-with-your-key" {
			return config{}, errors.New("IMAGEGEN_API_KEY is missing; set it locally, never paste it into chat")
		}
		parsed, _ := url.Parse(c.BaseURL)
		if parsed.Hostname() == "example" || strings.HasSuffix(parsed.Hostname(), ".example") {
			return config{}, errors.New("replace the example Base URL with your image API address")
		}
	}
	return c, nil
}

func validateURL(raw string) (*url.URL, error) {
	u, err := url.Parse(raw)
	if err != nil || u.Hostname() == "" || u.User != nil || u.Fragment != "" {
		return nil, errors.New("invalid URL (credentials and fragments are not allowed)")
	}
	ip := net.ParseIP(u.Hostname())
	local := strings.EqualFold(u.Hostname(), "localhost") || (ip != nil && ip.IsLoopback())
	if u.Scheme != "https" && !(u.Scheme == "http" && local) {
		return nil, errors.New("URL requires HTTPS; HTTP is allowed only for loopback development")
	}
	return u, nil
}

func normalizeBase(raw string) (string, error) {
	u, err := validateURL(raw)
	if err != nil || u.RawQuery != "" || u.ForceQuery {
		return "", errors.New("invalid IMAGEGEN_BASE_URL: use an HTTPS API root without credentials, query or fragment")
	}
	u.Path = strings.TrimRight(u.Path, "/")
	if u.Path == "" {
		u.Path = "/v1"
	}
	if strings.HasSuffix(u.Path, "/images/generations") || strings.HasSuffix(u.Path, "/images/edits") || strings.HasSuffix(u.Path, "/models") {
		return "", errors.New("Base URL must be the API root, not an images or models endpoint")
	}
	return strings.TrimRight(u.String(), "/"), nil
}

const configTemplate = `# imagegen-Z8 user configuration. Never commit this file or paste its key into chat.
# A domain alone gets /v1 appended; a path such as /api/v1 is used exactly as written.
IMAGEGEN_MODE=direct
IMAGEGEN_BASE_URL=https://your-relay.example/v1
IMAGEGEN_API_KEY=replace-with-your-key
IMAGEGEN_MODEL=gpt-image-2
`

func initConfig(path string) (map[string]any, error) {
	var err error
	if path == "" {
		path, err = defaultConfigPath()
	}
	if err != nil {
		return nil, err
	}
	path, err = filepath.Abs(path)
	if err != nil {
		return nil, errors.New("invalid configuration path")
	}
	if err = os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return nil, errors.New("cannot create configuration directory")
	}
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return nil, errors.New("configuration already exists or cannot be created; it was not overwritten")
	}
	_, writeErr := f.WriteString(configTemplate)
	closeErr := f.Close()
	if writeErr != nil || closeErr != nil {
		return nil, errors.New("cannot finish writing configuration template")
	}
	return map[string]any{"config_path": path, "configured": false, "next_step": "Edit this file locally, then run doctor. Do not paste your key into chat."}, nil
}
