package main

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const maxImageBytes = 50 * 1024 * 1024
const maxResponseBytes = 192 * 1024 * 1024

type imageResponse struct {
	Data []struct {
		B64 string `json:"b64_json"`
		URL string `json:"url"`
	} `json:"data"`
}

func httpClient(timeout time.Duration) *http.Client {
	return &http.Client{Timeout: timeout, CheckRedirect: func(req *http.Request, via []*http.Request) error {
		// API redirects are rejected; signed image downloads use a separate client below.
		return errors.New("API redirects are not followed")
	}}
}

func readLimited(reader io.Reader, limit int64) ([]byte, error) {
	body, err := io.ReadAll(io.LimitReader(reader, limit+1))
	if err != nil {
		return nil, errors.New("could not read response")
	}
	if int64(len(body)) > limit {
		return nil, errors.New("response exceeds the size limit")
	}
	return body, nil
}

func request(client *http.Client, cfg config, method, endpoint, contentType string, body []byte, attempts int) ([]byte, error) {
	for attempt := 1; attempt <= attempts; attempt++ {
		req, err := http.NewRequest(method, endpoint, bytes.NewReader(body))
		if err != nil {
			return nil, errors.New("could not construct API request")
		}
		req.Header.Set("Authorization", "Bearer "+cfg.key)
		req.Header.Set("User-Agent", "imagegen-Z8/"+version)
		if contentType != "" {
			req.Header.Set("Content-Type", contentType)
		}
		resp, err := client.Do(req)
		if err != nil {
			// A timed-out POST may have completed upstream. Avoid creating a duplicate paid job.
			return nil, errors.New("network error, timeout or redirect; completion is unknown, request was not automatically repeated")
		}
		status := resp.StatusCode
		if status >= 200 && status < 300 {
			data, readErr := readLimited(resp.Body, maxResponseBytes)
			resp.Body.Close()
			return data, readErr
		}
		resp.Body.Close()
		retryable := status == 429 || status == 500 || status == 502 || status == 503 || status == 504 || status == 524
		if !retryable || attempt == attempts {
			return nil, fmt.Errorf("API request failed with HTTP %d (response body hidden)", status)
		}
		time.Sleep(time.Duration(attempt) * 500 * time.Millisecond)
	}
	return nil, errors.New("API request did not run")
}

func downloadImage(rawURL string, timeout time.Duration) ([]byte, error) {
	if _, err := validateURL(rawURL); err != nil {
		return nil, errors.New("API returned an invalid image URL")
	}
	// No upstream Authorization header is ever attached to download requests.
	client := &http.Client{Timeout: timeout, CheckRedirect: func(req *http.Request, via []*http.Request) error {
		if len(via) >= 5 {
			return errors.New("too many image redirects")
		}
		_, err := validateURL(req.URL.String())
		if err != nil {
			return err
		}
		if via[0].URL.Scheme == "https" && req.URL.Scheme != "https" {
			return errors.New("image redirect cannot downgrade HTTPS")
		}
		return nil
	}}
	resp, err := client.Get(rawURL)
	if err != nil {
		return nil, errors.New("could not download image (URL hidden)")
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, fmt.Errorf("image download failed with HTTP %d", resp.StatusCode)
	}
	return readLimited(resp.Body, maxImageBytes)
}

func imageFormat(data []byte) string {
	if len(data) >= 8 && bytes.Equal(data[:8], []byte{137, 80, 78, 71, 13, 10, 26, 10}) {
		return "png"
	}
	if len(data) >= 3 && data[0] == 255 && data[1] == 216 && data[2] == 255 {
		return "jpeg"
	}
	if len(data) >= 12 && string(data[:4]) == "RIFF" && string(data[8:12]) == "WEBP" {
		return "webp"
	}
	return ""
}

func decodeImages(raw []byte, count int, format string, timeout time.Duration) ([][]byte, error) {
	var result imageResponse
	if json.Unmarshal(raw, &result) != nil {
		return nil, errors.New("API returned invalid JSON")
	}
	if len(result.Data) != count {
		return nil, fmt.Errorf("API returned %d images; expected %d", len(result.Data), count)
	}
	images := make([][]byte, 0, count)
	for _, item := range result.Data {
		var data []byte
		var err error
		if item.B64 != "" {
			if base64.StdEncoding.DecodedLen(len(item.B64)) > maxImageBytes {
				return nil, errors.New("image exceeds the size limit")
			}
			data, err = base64.StdEncoding.DecodeString(item.B64)
			if err != nil {
				return nil, errors.New("API returned invalid base64 image data")
			}
		} else if item.URL != "" {
			data, err = downloadImage(item.URL, timeout)
		} else {
			return nil, errors.New("API image entry contains neither b64_json nor url")
		}
		if err != nil {
			return nil, err
		}
		actual := imageFormat(data)
		if actual == "" {
			return nil, errors.New("API returned unrecognized image bytes; no output was saved")
		}
		if actual != format {
			return nil, fmt.Errorf("API returned %s but %s was requested; choose --output-format %s and a matching extension", actual, format, actual)
		}
		images = append(images, data)
	}
	return images, nil
}

func multipartBody(job job, options options) ([]byte, string, error) {
	var body bytes.Buffer
	w := multipart.NewWriter(&body)
	for key, value := range payload(job, options) {
		if err := w.WriteField(key, fmt.Sprint(value)); err != nil {
			return nil, "", errors.New("cannot encode edit field")
		}
	}
	for i, path := range append(append([]string{}, job.Images...), job.Mask) {
		if path == "" {
			continue
		}
		name := "image"
		if len(job.Images) > 1 {
			name = "image[]"
		}
		if i == len(job.Images) {
			name = "mask"
		}
		part, err := w.CreateFormFile(name, filepath.Base(path))
		if err != nil {
			return nil, "", errors.New("cannot encode edit image")
		}
		f, err := os.Open(path)
		if err != nil {
			return nil, "", errors.New("cannot open edit image")
		}
		data, readErr := readLimited(f, maxImageBytes)
		f.Close()
		if readErr != nil {
			return nil, "", readErr
		}
		if _, err = part.Write(data); err != nil {
			return nil, "", errors.New("cannot encode edit image")
		}
		if body.Len() > maxResponseBytes {
			return nil, "", errors.New("combined edit inputs exceed the size limit")
		}
	}
	if w.Close() != nil {
		return nil, "", errors.New("cannot finish edit request")
	}
	return body.Bytes(), w.FormDataContentType(), nil
}

func payload(job job, options options) map[string]any {
	value := map[string]any{"model": job.Model, "prompt": job.Prompt, "size": job.Size, "quality": job.Quality, "n": job.N, "output_format": job.Format}
	if options.background != "" {
		value["background"] = options.background
	}
	return value
}

func saveImages(images [][]byte, paths []string, force bool) ([]string, error) {
	if len(images) != len(paths) {
		return nil, errors.New("output count mismatch")
	}
	// Reserve all destinations before writing any bytes. O_EXCL closes the preflight race.
	files := make([]*os.File, 0, len(paths))
	for _, path := range paths {
		if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
			closeFiles(files)
			return nil, errors.New("cannot create output directory")
		}
		flags := os.O_WRONLY | os.O_CREATE | os.O_EXCL
		if force {
			flags = os.O_WRONLY | os.O_CREATE
		}
		f, err := os.OpenFile(path, flags, 0644)
		if err != nil {
			closeFiles(files)
			if !force {
				for _, reserved := range paths[:len(files)] {
					_ = os.Remove(reserved)
				}
			}
			return nil, errors.New("cannot reserve outputs; a file may already exist (use a new name)")
		}
		files = append(files, f)
	}
	for i, f := range files {
		if err := f.Truncate(0); err != nil {
			closeFiles(files)
			return nil, errors.New("cannot prepare output; inspect destination files")
		}
		if _, err := f.Write(images[i]); err != nil {
			closeFiles(files)
			return nil, errors.New("cannot write output; inspect destination files for partial results")
		}
	}
	for _, f := range files {
		if err := f.Close(); err != nil {
			closeFiles(files)
			return nil, errors.New("cannot close output; inspect destination files")
		}
	}
	return paths, nil
}

func closeFiles(files []*os.File) {
	for _, f := range files {
		_ = f.Close()
	}
}

func execute(cfg config, item preparedJob, opts options) (map[string]any, error) {
	operation := "generations"
	if len(item.Job.Images) > 0 {
		operation = "edits"
	}
	endpoint := ""
	if cfg.BaseURL != "" {
		endpoint = cfg.BaseURL + "/images/" + operation
	}
	if opts.dryRun {
		return map[string]any{"dry_run": true, "endpoint": endpoint, "payload": payload(item.Job, opts), "images": item.Job.Images, "mask": item.Job.Mask, "outputs": item.Paths, "config_source": cfg.Source}, nil
	}
	body, err := json.Marshal(payload(item.Job, opts))
	contentType := "application/json"
	if operation == "edits" {
		body, contentType, err = multipartBody(item.Job, opts)
	}
	if err != nil {
		return nil, err
	}
	raw, err := request(httpClient(opts.timeout), cfg, "POST", endpoint, contentType, body, opts.attempts)
	if err != nil {
		return nil, err
	}
	images, err := decodeImages(raw, item.Job.N, item.Job.Format, opts.timeout)
	if err != nil {
		return nil, err
	}
	paths, err := saveImages(images, item.Paths, opts.force)
	if err != nil {
		return nil, err
	}
	return map[string]any{"model": item.Job.Model, "requested_size": item.Job.Size, "requested_quality": item.Job.Quality, "format": item.Job.Format, "outputs": paths}, nil
}

func doctor(cfg config, online bool, timeout time.Duration) (map[string]any, error) {
	result := map[string]any{"version": version, "mode": cfg.Mode, "config_source": cfg.Source, "base_url": cfg.BaseURL, "model": cfg.Model, "key_configured": cfg.key != "", "local_config_valid": true, "image_generation_verified": false, "online_checked": false}
	if !online {
		return result, nil
	}
	body, err := request(httpClient(timeout), cfg, "GET", cfg.BaseURL+"/models", "", nil, 1)
	if err != nil {
		return nil, err
	}
	var response struct {
		Data []struct {
			ID string `json:"id"`
		} `json:"data"`
	}
	if json.Unmarshal(body, &response) != nil || response.Data == nil {
		return nil, errors.New("models endpoint returned an unsupported response; this does not establish image endpoint availability")
	}
	models := []string{}
	present := false
	for _, model := range response.Data {
		if model.ID == cfg.Model {
			present = true
		}
		if model.ID != "" && model.ID != cfg.key && len(model.ID) <= 256 && !strings.ContainsAny(model.ID, "\r\n\x00") {
			models = append(models, model.ID)
		}
	}
	result["online_checked"], result["models"], result["configured_model_listed"] = true, models, present
	result["note"] = "Model listing does not prove image generation permission. No image was generated."
	return result, nil
}
