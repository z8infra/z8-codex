package main

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"image"
	"image/color"
	"image/png"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func fixturePNG(t *testing.T) []byte {
	t.Helper()
	img := image.NewNRGBA(image.Rect(0, 0, 2, 2))
	img.Set(0, 0, color.NRGBA{R: 255, A: 255})
	var b bytes.Buffer
	if err := png.Encode(&b, img); err != nil {
		t.Fatal(err)
	}
	return b.Bytes()
}
func fixtureConfig(t *testing.T, base string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "config.env")
	write(t, path, []byte("IMAGEGEN_MODE=direct\nIMAGEGEN_BASE_URL="+base+"\nIMAGEGEN_API_KEY=test-secret-not-for-output\nIMAGEGEN_MODEL=fixture-image\n"))
	return path
}
func write(t *testing.T, path string, data []byte) {
	t.Helper()
	if err := os.WriteFile(path, data, 0600); err != nil {
		t.Fatal(err)
	}
}
func invoke(t *testing.T, args ...string) (map[string]any, error) {
	t.Helper()
	var out bytes.Buffer
	err := run(args, &out)
	if strings.Contains(out.String(), "test-secret-not-for-output") {
		t.Fatal("credential leaked in output")
	}
	if err != nil && strings.Contains(err.Error(), "test-secret-not-for-output") {
		t.Fatal("credential leaked in error")
	}
	var result map[string]any
	if out.Len() > 0 {
		if decodeErr := json.Unmarshal(out.Bytes(), &result); decodeErr != nil {
			t.Fatalf("invalid JSON output: %s", out.String())
		}
	}
	return result, err
}

func TestConfigurationSourcesAreAtomic(t *testing.T) {
	path := fixtureConfig(t, "https://file.example.net/api/v1")
	t.Setenv("IMAGEGEN_BASE_URL", "https://environment.example.net")
	t.Setenv("IMAGEGEN_API_KEY", "environment-secret")
	t.Setenv("IMAGEGEN_MODEL", "environment-model")
	t.Setenv("IMAGEGEN_CONFIG", "")
	cfg, err := loadConfig(path, false)
	if err != nil || cfg.Model != "fixture-image" || cfg.key != "test-secret-not-for-output" || cfg.BaseURL != "https://file.example.net/api/v1" {
		t.Fatalf("explicit source did not win: %v", err)
	}
	cfg, err = loadConfig("", false)
	if err != nil || cfg.Model != "environment-model" || cfg.BaseURL != "https://environment.example.net/v1" {
		t.Fatalf("environment source failed: %v", err)
	}
	t.Setenv("IMAGEGEN_API_KEY", "")
	if _, err = loadConfig("", false); err == nil {
		t.Fatal("partial environment must not borrow a file key")
	}
	t.Setenv("IMAGEGEN_CONFIG", path)
	if _, err = loadConfig("", false); err != nil {
		t.Fatal("explicit environment path should override individual environment fields")
	}
}

func TestDotEnvParsingDoesNotEvaluateOrRevealValues(t *testing.T) {
	path := filepath.Join(t.TempDir(), ".env")
	write(t, path, []byte("\ufeff# comment\r\nexport IMAGEGEN_MODE=direct\r\nIMAGEGEN_API_KEY='literal$()#key' # comment\r\nIMAGEGEN_BASE_URL= https://api.example.net/v1 # comment\r\n"))
	values, err := readDotEnv(path)
	if err != nil || values["IMAGEGEN_API_KEY"] != "literal$()#key" {
		t.Fatal("dotenv literal parsing failed")
	}
	write(t, path, []byte("IMAGEGEN_API_KEY=test-secret-not-for-output\nIMAGEGEN_API_KEY=duplicate\n"))
	if _, err = readDotEnv(path); err == nil || strings.Contains(err.Error(), "test-secret") {
		t.Fatal("duplicate key or secret redaction failure")
	}
	write(t, path, []byte("IMAGEGEN_API_KEY='test-secret-not-for-output\n"))
	if _, err = readDotEnv(path); err == nil || strings.Contains(err.Error(), "test-secret") {
		t.Fatal("malformed config must fail without values")
	}
}

func TestBaseURLHandling(t *testing.T) {
	for input, want := range map[string]string{"https://api.example.net": "https://api.example.net/v1", "https://api.example.net/v1/": "https://api.example.net/v1", "https://api.example.net/api/image/v2": "https://api.example.net/api/image/v2", "http://127.0.0.1:9090": "http://127.0.0.1:9090/v1"} {
		got, err := normalizeBase(input)
		if err != nil || got != want {
			t.Errorf("%s => %s (%v)", input, got, err)
		}
	}
	for _, input := range []string{"http://remote.example.net/v1", "https://user:secret@api.example.net/v1", "https://api.example.net/v1?key=secret", "https://api.example.net/v1/images/generations", "https://api.example.net/v1#fragment"} {
		if _, err := normalizeBase(input); err == nil {
			t.Errorf("accepted invalid base %s", input)
		}
	}
}

func TestConfigInitPreservesExistingFileAndManagedModeIsExplicit(t *testing.T) {
	path := filepath.Join(t.TempDir(), "settings", ".env")
	if _, err := initConfig(path); err != nil {
		t.Fatal(err)
	}
	original, _ := os.ReadFile(path)
	if _, err := initConfig(path); err == nil {
		t.Fatal("existing config was overwritten")
	}
	after, _ := os.ReadFile(path)
	if !bytes.Equal(original, after) {
		t.Fatal("configuration changed")
	}
	write(t, path, []byte("IMAGEGEN_MODE=z8\nIMAGEGEN_KEY_ID=one\n"))
	if _, err := loadConfig(path, true); err == nil || !strings.Contains(err.Error(), "reserved") {
		t.Fatal("future mode must fail clearly")
	}
}

func TestGenerateAndDoctorAgainstImageAPI(t *testing.T) {
	data := fixturePNG(t)
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		if r.Header.Get("Authorization") != "Bearer test-secret-not-for-output" {
			t.Error("missing authorization")
		}
		switch r.URL.Path {
		case "/v1/models":
			io.WriteString(w, `{"data":[{"id":"fixture-image"}]}`)
		case "/v1/images/generations":
			if r.Method != "POST" {
				t.Error("wrong method")
			}
			var body map[string]any
			if json.NewDecoder(r.Body).Decode(&body) != nil {
				t.Error("bad JSON")
			}
			if body["model"] != "fixture-image" || body["output_format"] != "png" || body["prompt"] != "a cat" {
				t.Errorf("unexpected payload %v", body)
			}
			json.NewEncoder(w).Encode(map[string]any{"data": []map[string]string{{"b64_json": base64.StdEncoding.EncodeToString(data)}}})
		default:
			t.Error("unexpected endpoint")
			w.WriteHeader(404)
		}
	}))
	defer server.Close()
	path := fixtureConfig(t, server.URL)
	result, err := invoke(t, "doctor", "--config", path)
	if err != nil || result["image_generation_verified"] != false || calls.Load() != 0 {
		t.Fatal("offline doctor performed network or made incorrect claim")
	}
	result, err = invoke(t, "doctor", "--config", path, "--online")
	if err != nil || result["configured_model_listed"] != true || result["image_generation_verified"] != false {
		t.Fatalf("online doctor failed: %v", err)
	}
	dir := t.TempDir()
	result, err = invoke(t, "generate", "--config", path, "--prompt", "a cat", "--out-dir", dir, "--out", "nested/cat.png")
	if err != nil {
		t.Fatal(err)
	}
	out := result["outputs"].([]any)[0].(string)
	if out != filepath.Join(dir, "nested", "cat.png") {
		t.Fatalf("wrong output resolution: %s", out)
	}
	written, _ := os.ReadFile(out)
	if !bytes.Equal(data, written) {
		t.Fatal("saved image differs")
	}
	before := calls.Load()
	if _, err = invoke(t, "generate", "--config", path, "--prompt", "a cat", "--out", out); err == nil || calls.Load() != before {
		t.Fatal("existing file was not rejected before API request")
	}
}

func TestReferenceImagesAndMaskUseMultipartEdits(t *testing.T) {
	data := fixturePNG(t)
	dir := t.TempDir()
	first := filepath.Join(dir, "one.png")
	second := filepath.Join(dir, "two.png")
	mask := filepath.Join(dir, "mask.png")
	for _, path := range []string{first, second, mask} {
		write(t, path, data)
	}
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		if r.URL.Path != "/v1/images/edits" {
			t.Error("references did not use edits endpoint")
		}
		if err := r.ParseMultipartForm(1024 * 1024); err != nil {
			t.Error(err)
			w.WriteHeader(400)
			return
		}
		defer r.MultipartForm.RemoveAll()
		if len(r.MultipartForm.File["image[]"]) != 2 || len(r.MultipartForm.File["mask"]) != 1 || r.FormValue("model") != "fixture-image" {
			t.Error("multipart fields not preserved")
		}
		json.NewEncoder(w).Encode(map[string]any{"data": []map[string]string{{"b64_json": base64.StdEncoding.EncodeToString(data)}}})
	}))
	defer server.Close()
	path := fixtureConfig(t, server.URL)
	_, err := invoke(t, "generate", "--config", path, "--prompt", "new composition", "--image", first, "--image", second, "--mask", mask, "--out", filepath.Join(dir, "result.png"))
	if err != nil || calls.Load() != 1 {
		t.Fatal(err)
	}
	if _, err = invoke(t, "edit", "--config", path, "--prompt", "edit", "--image", first, "--out", first, "--force"); err == nil || calls.Load() != 1 {
		t.Fatal("input overwrite allowed")
	}
}

func TestImageDownloadDoesNotReceiveAPIKeyAndAPIRedirectIsRejected(t *testing.T) {
	data := fixturePNG(t)
	var downloads atomic.Int32
	cdn := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		downloads.Add(1)
		if r.Header.Get("Authorization") != "" {
			t.Error("credential sent to image URL")
		}
		w.Write(data)
	}))
	defer cdn.Close()
	api := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(map[string]any{"data": []map[string]string{{"url": cdn.URL + "/image?signature=test"}}})
	}))
	defer api.Close()
	_, err := invoke(t, "generate", "--config", fixtureConfig(t, api.URL), "--prompt", "download", "--out-dir", t.TempDir())
	if err != nil || downloads.Load() != 1 {
		t.Fatalf("download failed: %v", err)
	}
	redirect := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, cdn.URL, http.StatusTemporaryRedirect)
	}))
	defer redirect.Close()
	_, err = invoke(t, "generate", "--config", fixtureConfig(t, redirect.URL), "--prompt", "redirect", "--out-dir", t.TempDir())
	if err == nil || downloads.Load() != 1 {
		t.Fatal("API redirect forwarded credentials")
	}
}

func TestHTTPFailuresDoNotLeakAndRetryIsOptIn(t *testing.T) {
	var calls atomic.Int32
	var status atomic.Int32
	status.Store(http.StatusServiceUnavailable)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		w.WriteHeader(int(status.Load()))
		io.WriteString(w, "test-secret-not-for-output")
	}))
	defer server.Close()
	path := fixtureConfig(t, server.URL)
	if _, err := invoke(t, "generate", "--config", path, "--prompt", "failure", "--out-dir", t.TempDir()); err == nil || calls.Load() != 1 {
		t.Fatal("default failure retried")
	}
	if _, err := invoke(t, "generate", "--config", path, "--prompt", "failure", "--out-dir", t.TempDir(), "--max-attempts", "2"); err == nil || calls.Load() != 3 {
		t.Fatal("explicit retry failed")
	}
	status.Store(http.StatusUnauthorized)
	if _, err := invoke(t, "generate", "--config", path, "--prompt", "failure", "--out-dir", t.TempDir(), "--max-attempts", "3"); err == nil || calls.Load() != 4 {
		t.Fatal("auth failure was retried")
	}
}

func TestDryRunNoNetworkAndBatchPreflight(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { calls.Add(1); w.WriteHeader(500) }))
	defer server.Close()
	path := fixtureConfig(t, server.URL)
	dir := t.TempDir()
	result, err := invoke(t, "generate", "--config", path, "--prompt", "a cat", "--dry-run", "--out-dir", dir)
	if err != nil || result["dry_run"] != true || calls.Load() != 0 {
		t.Fatal("dry-run contacted API")
	}
	entries, _ := os.ReadDir(dir)
	if len(entries) != 0 {
		t.Fatal("dry-run wrote outputs")
	}
	batch := filepath.Join(t.TempDir(), "jobs.jsonl")
	write(t, batch, []byte("{\"prompt\":\"one\",\"out\":\"same.png\"}\n{\"prompt\":\"two\",\"out\":\"SAME.png\"}\n"))
	if _, err = invoke(t, "generate-batch", "--config", path, "--input", batch, "--out-dir", dir); err == nil || calls.Load() != 0 {
		t.Fatal("colliding batch submitted")
	}
	write(t, batch, []byte("{\"prompt\":\"one\",\"out\":\"one.png\"}\n{\"prompt\":\"two\",\"n\":-1}\n"))
	if _, err = invoke(t, "generate-batch", "--config", path, "--input", batch, "--out-dir", dir); err == nil || calls.Load() != 0 {
		t.Fatal("invalid later job not caught before submit")
	}
	write(t, batch, []byte("{\"prompt\":\"one\",\"out\":\"one.png\"}\n{\"prompt\":\"two\",\"out\":\"two.png\"}\n{\"prompt\":\"three\",\"out\":\"three.png\"}\n"))
	result, err = invoke(t, "generate-batch", "--config", path, "--input", batch, "--out-dir", dir, "--fail-fast", "--concurrency", "1")
	if err == nil || result["failed"] != float64(1) || result["skipped"] != float64(2) || calls.Load() != 1 {
		t.Fatalf("fail-fast summary wrong: %v", result)
	}
}

func TestResponseAndSaveValidation(t *testing.T) {
	if _, err := decodeImages([]byte(`{"data":[{"b64_json":"aGVsbG8="}]}`), 1, "png", time.Second); err == nil {
		t.Fatal("non-image accepted")
	}
	if _, err := decodeImages([]byte(`{"data":[]}`), 1, "png", time.Second); err == nil {
		t.Fatal("wrong count accepted")
	}
	dir := t.TempDir()
	first := filepath.Join(dir, "first.png")
	second := filepath.Join(dir, "second.png")
	write(t, second, []byte("original"))
	if _, err := saveImages([][]byte{fixturePNG(t), fixturePNG(t)}, []string{first, second}, false); err == nil {
		t.Fatal("existing destination accepted")
	}
	if _, err := os.Stat(first); !os.IsNotExist(err) {
		t.Fatal("empty reservation left after conflict")
	}
	data, _ := os.ReadFile(second)
	if string(data) != "original" {
		t.Fatal("existing output changed")
	}
}

func TestConcurrentBatchKeepsSuccessfulOutputsAndModelOverrides(t *testing.T) {
	data := fixturePNG(t)
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		var payload map[string]any
		if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
			t.Error(err)
			w.WriteHeader(400)
			return
		}
		if payload["prompt"] == "fail" {
			w.WriteHeader(403)
			return
		}
		if payload["model"] != "job-model" {
			t.Error("job model did not override CLI default")
		}
		items := []map[string]string{}
		for i := 0; i < int(payload["n"].(float64)); i++ {
			items = append(items, map[string]string{"b64_json": base64.StdEncoding.EncodeToString(data)})
		}
		json.NewEncoder(w).Encode(map[string]any{"data": items})
	}))
	defer server.Close()
	batch := filepath.Join(t.TempDir(), "jobs.jsonl")
	write(t, batch, []byte("{\"prompt\":\"variants\",\"model\":\"job-model\",\"n\":2,\"out\":\"pair.png\"}\n{\"prompt\":\"fail\",\"out\":\"failure.png\"}\n"))
	dir := t.TempDir()
	result, err := invoke(t, "generate-batch", "--config", fixtureConfig(t, server.URL), "--input", batch, "--out-dir", dir, "--concurrency", "2", "--model", "cli-model")
	if err == nil || calls.Load() != 2 || result["succeeded"] != float64(1) || result["failed"] != float64(1) {
		t.Fatalf("unexpected summary: %v", result)
	}
	for _, name := range []string{"pair-1.png", "pair-2.png"} {
		output, err := os.ReadFile(filepath.Join(dir, name))
		if err != nil || !bytes.Equal(output, data) {
			t.Fatal("successful variants not preserved")
		}
	}
	if _, err := os.Stat(filepath.Join(dir, "failure.png")); !os.IsNotExist(err) {
		t.Fatal("failed job created output")
	}
}

func TestTimeoutDoesNotResubmitEvenWithRetryOption(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		time.Sleep(100 * time.Millisecond)
		io.WriteString(w, `{"data":[]}`)
	}))
	defer server.Close()
	_, err := invoke(t, "generate", "--config", fixtureConfig(t, server.URL), "--prompt", "timeout", "--timeout", "0.02", "--max-attempts", "3", "--out-dir", t.TempDir())
	if err == nil || !strings.Contains(err.Error(), "unknown") || calls.Load() != 1 {
		t.Fatal("uncertain POST was retried or not reported correctly")
	}
}
