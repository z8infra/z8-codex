package main

import (
	"bufio"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

type job struct {
	Prompt  string   `json:"prompt"`
	Model   string   `json:"model,omitempty"`
	Size    string   `json:"size,omitempty"`
	Quality string   `json:"quality,omitempty"`
	N       int      `json:"n,omitempty"`
	Out     string   `json:"out,omitempty"`
	Format  string   `json:"output_format,omitempty"`
	Images  []string `json:"images,omitempty"`
	Mask    string   `json:"mask,omitempty"`
}

type options struct {
	configPath, promptFile, input, outDir, background string
	dryRun, force, online, failFast                   bool
	concurrency, attempts                             int
	timeout                                           time.Duration
}

type preparedJob struct {
	Job   job
	Paths []string
}
type batchResult struct {
	Index  int            `json:"index"`
	Status string         `json:"status"`
	Data   map[string]any `json:"data,omitempty"`
	Error  string         `json:"error,omitempty"`
}
type stringList []string

func (s *stringList) String() string         { return strings.Join(*s, ",") }
func (s *stringList) Set(value string) error { *s = append(*s, value); return nil }

func prepareJob(j job, defaults job, opts options, index int) (preparedJob, error) {
	if strings.TrimSpace(j.Prompt) == "" {
		return preparedJob{}, errors.New("prompt is required")
	}
	if j.Model == "" {
		j.Model = defaults.Model
	}
	if j.Size == "" {
		j.Size = defaults.Size
	}
	if j.Quality == "" {
		j.Quality = defaults.Quality
	}
	if j.N == 0 {
		j.N = defaults.N
	}
	if j.Format == "" {
		j.Format = defaults.Format
	}
	if j.N < 1 || j.N > 10 {
		return preparedJob{}, errors.New("n must be between 1 and 10")
	}
	if j.Model == "" || len(j.Model) > 256 || strings.ContainsAny(j.Model, "\r\n\x00") {
		return preparedJob{}, errors.New("invalid model identifier")
	}
	if j.Quality != "auto" && j.Quality != "low" && j.Quality != "medium" && j.Quality != "high" {
		return preparedJob{}, errors.New("quality must be auto, low, medium or high")
	}
	if j.Format != "png" && j.Format != "jpeg" && j.Format != "webp" {
		return preparedJob{}, errors.New("output-format must be png, jpeg or webp")
	}
	if j.Size != "auto" {
		w, h, ok := strings.Cut(j.Size, "x")
		width, ew := strconv.Atoi(w)
		height, eh := strconv.Atoi(h)
		if !ok || ew != nil || eh != nil || width < 1 || height < 1 || width > 16384 || height > 16384 {
			return preparedJob{}, errors.New("size must be auto or WIDTHxHEIGHT with positive edges up to 16384; actual limits depend on the model")
		}
	}
	if opts.background != "" && opts.background != "auto" && opts.background != "opaque" && opts.background != "transparent" {
		return preparedJob{}, errors.New("background must be auto, opaque or transparent")
	}
	if opts.background == "transparent" && j.Format == "jpeg" {
		return preparedJob{}, errors.New("transparent output requires PNG or WebP")
	}
	if j.Mask != "" && len(j.Images) == 0 {
		return preparedJob{}, errors.New("mask requires an input image")
	}
	if len(j.Images) > 16 {
		return preparedJob{}, errors.New("at most 16 input images are supported")
	}
	var total int64
	for i, path := range append(append([]string{}, j.Images...), j.Mask) {
		if path == "" {
			if i < len(j.Images) {
				return preparedJob{}, errors.New("empty image path")
			}
			continue
		}
		info, err := os.Stat(path)
		if err != nil || !info.Mode().IsRegular() || info.Size() < 1 || info.Size() > maxImageBytes {
			return preparedJob{}, errors.New("input image is missing, empty, not a regular file, or larger than 50 MiB")
		}
		total += info.Size()
		f, err := os.Open(path)
		if err != nil {
			return preparedJob{}, errors.New("cannot inspect input image")
		}
		header := make([]byte, 12)
		n, _ := f.Read(header)
		f.Close()
		format := imageFormat(header[:n])
		if format == "" {
			return preparedJob{}, errors.New("input must be a PNG, JPEG or WebP image")
		}
		if i == len(j.Images) && format != "png" {
			return preparedJob{}, errors.New("mask must be PNG")
		}
	}
	if total > 128*1024*1024 {
		return preparedJob{}, errors.New("combined input images exceed 128 MiB")
	}
	ext := "." + j.Format
	out := j.Out
	if out == "" {
		sum := sha256.Sum256([]byte(j.Prompt))
		out = fmt.Sprintf("image-%s-%03d-%x%s", time.Now().UTC().Format("20060102-150405.000000000"), index, sum[:4], ext)
	}
	if filepath.Ext(out) == "" {
		out += ext
	}
	actualExt := strings.ToLower(filepath.Ext(out))
	if actualExt != ext && !(j.Format == "jpeg" && actualExt == ".jpg") {
		return preparedJob{}, errors.New("output extension does not match output-format")
	}
	if !filepath.IsAbs(out) {
		out = filepath.Join(opts.outDir, out)
	}
	out, err := filepath.Abs(out)
	if err != nil {
		return preparedJob{}, errors.New("invalid output path")
	}
	paths := make([]string, j.N)
	for i := range paths {
		paths[i] = out
		if j.N > 1 {
			paths[i] = strings.TrimSuffix(out, filepath.Ext(out)) + fmt.Sprintf("-%d", i+1) + filepath.Ext(out)
		}
		info, statErr := os.Lstat(paths[i])
		if statErr == nil {
			if !opts.force {
				return preparedJob{}, errors.New("output already exists; choose a new name or explicitly use --force")
			}
			if !info.Mode().IsRegular() {
				return preparedJob{}, errors.New("refusing to replace an output that is not a regular file")
			}
		} else if !os.IsNotExist(statErr) {
			return preparedJob{}, errors.New("cannot inspect output path")
		}
		for _, input := range append(append([]string{}, j.Images...), j.Mask) {
			if input == "" {
				continue
			}
			absolute, _ := filepath.Abs(input)
			if samePath(absolute, paths[i]) {
				return preparedJob{}, errors.New("output must not overwrite an input image or mask")
			}
			if statErr == nil {
				source, err := os.Stat(input)
				if err == nil && os.SameFile(info, source) {
					return preparedJob{}, errors.New("output aliases an input file")
				}
			}
		}
	}
	return preparedJob{Job: j, Paths: paths}, nil
}

// Case-fold for collision checks on all platforms: portable batches should not differ only in casing.
func samePath(a, b string) bool { return strings.EqualFold(filepath.Clean(a), filepath.Clean(b)) }

func readBatch(path string) ([]job, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, errors.New("cannot read batch input")
	}
	defer f.Close()
	s := bufio.NewScanner(f)
	s.Buffer(make([]byte, 4096), 1024*1024)
	jobs := []job{}
	line := 0
	for s.Scan() {
		line++
		text := strings.TrimSpace(strings.TrimPrefix(s.Text(), "\ufeff"))
		if text == "" || strings.HasPrefix(text, "#") {
			continue
		}
		var j job
		d := json.NewDecoder(strings.NewReader(text))
		d.DisallowUnknownFields()
		if d.Decode(&j) != nil {
			return nil, fmt.Errorf("invalid batch JSON at line %d (values hidden)", line)
		}
		var extra any
		if d.Decode(&extra) != io.EOF {
			return nil, fmt.Errorf("extra JSON at line %d", line)
		}
		jobs = append(jobs, j)
		if len(jobs) > 500 {
			return nil, errors.New("batch is limited to 500 jobs")
		}
	}
	if s.Err() != nil {
		return nil, errors.New("cannot read batch: line too large or input error")
	}
	if len(jobs) == 0 {
		return nil, errors.New("batch contains no jobs")
	}
	return jobs, nil
}

func prepareBatch(jobs []job, defaults job, opts options) ([]preparedJob, error) {
	items := make([]preparedJob, len(jobs))
	seen := map[string]bool{}
	for i, j := range jobs {
		item, err := prepareJob(j, defaults, opts, i+1)
		if err != nil {
			return nil, fmt.Errorf("job %d: %w", i+1, err)
		}
		for _, path := range item.Paths {
			key := strings.ToLower(filepath.Clean(path))
			if seen[key] {
				return nil, errors.New("batch output paths collide; use unique names")
			}
			seen[key] = true
		}
		items[i] = item
	}
	// Cross-job input/output collisions are also invalid, even with --force.
	for _, item := range items {
		for _, input := range append(append([]string{}, item.Job.Images...), item.Job.Mask) {
			if input == "" {
				continue
			}
			absolute, _ := filepath.Abs(input)
			if seen[strings.ToLower(filepath.Clean(absolute))] {
				return nil, errors.New("a batch output overwrites another job's input")
			}
		}
	}
	return items, nil
}

func executeBatch(cfg config, items []preparedJob, opts options) (map[string]any, error) {
	results := make([]batchResult, len(items))
	for i := range results {
		results[i] = batchResult{Index: i + 1, Status: "skipped"}
	}
	var lock sync.Mutex
	var workers sync.WaitGroup
	next := 0
	failed := false
	for worker := 0; worker < opts.concurrency; worker++ {
		workers.Add(1)
		go func() {
			defer workers.Done()
			for {
				lock.Lock()
				if next == len(items) || (failed && opts.failFast) {
					lock.Unlock()
					return
				}
				index := next
				next++
				lock.Unlock()
				data, err := execute(cfg, items[index], opts)
				result := batchResult{Index: index + 1, Status: "succeeded", Data: data}
				if err != nil {
					result.Status = "failed"
					result.Error = err.Error()
				}
				lock.Lock()
				results[index] = result
				if err != nil {
					failed = true
				}
				lock.Unlock()
			}
		}()
	}
	workers.Wait()
	counts := map[string]int{"succeeded": 0, "failed": 0, "skipped": 0}
	for _, result := range results {
		counts[result.Status]++
	}
	summary := map[string]any{"jobs": results, "succeeded": counts["succeeded"], "failed": counts["failed"], "skipped": counts["skipped"], "dry_run": opts.dryRun}
	if failed {
		return summary, errors.New("one or more batch jobs failed; inspect the per-job results")
	}
	return summary, nil
}

func run(argv []string, output io.Writer) error {
	if len(argv) == 0 || argv[0] == "help" || argv[0] == "--help" || argv[0] == "-h" {
		_, err := fmt.Fprintln(output, "imagegen-Z8 "+version+"\nCommands: config-init, doctor [--online], generate, edit, generate-batch, version\nUse <command> --help for options. Credentials are read locally, never from CLI flags.")
		return err
	}
	command := argv[0]
	if command == "version" || command == "--version" {
		return json.NewEncoder(output).Encode(map[string]string{"name": "imagegen-Z8", "version": version})
	}
	if command != "config-init" && command != "doctor" && command != "generate" && command != "edit" && command != "generate-batch" {
		return errors.New("unknown command; run --help")
	}
	fs := flag.NewFlagSet(command, flag.ContinueOnError)
	fs.SetOutput(output)
	opts := options{}
	fs.StringVar(&opts.configPath, "config", "", "explicit dotenv file; overrides environment and default file")
	var j job
	var images stringList
	var seconds float64
	if command == "doctor" {
		fs.BoolVar(&opts.online, "online", false, "GET /models; never generates a billable image")
		fs.Float64Var(&seconds, "timeout", 30, "network timeout in seconds")
	} else if command != "config-init" {
		fs.StringVar(&j.Model, "model", "", "override the configured image model")
		fs.StringVar(&j.Size, "size", "1024x1024", "auto or WIDTHxHEIGHT")
		fs.StringVar(&j.Quality, "quality", "auto", "auto, low, medium or high")
		fs.StringVar(&j.Format, "output-format", "png", "png, jpeg or webp")
		fs.IntVar(&j.N, "n", 1, "variants of each prompt (1-10)")
		fs.StringVar(&opts.outDir, "out-dir", "output/imagegen", "base directory for every relative output path")
		fs.StringVar(&opts.background, "background", "", "optional provider-supported auto, opaque or transparent")
		fs.BoolVar(&opts.dryRun, "dry-run", false, "validate without network, credentials or output files")
		fs.BoolVar(&opts.force, "force", false, "explicitly replace existing output files; never input images")
		fs.IntVar(&opts.attempts, "max-attempts", 1, "HTTP attempts (1-5); raising this may duplicate upstream jobs")
		fs.Float64Var(&seconds, "timeout", 180, "network timeout in seconds (max 1800)")
		if command == "generate-batch" {
			fs.StringVar(&opts.input, "input", "", "UTF-8 JSONL file")
			fs.IntVar(&opts.concurrency, "concurrency", 2, "concurrent jobs (1-8)")
			fs.BoolVar(&opts.failFast, "fail-fast", false, "stop scheduling new jobs after a failure; running jobs finish")
		} else {
			fs.StringVar(&j.Prompt, "prompt", "", "image prompt")
			fs.StringVar(&opts.promptFile, "prompt-file", "", "UTF-8 prompt file, alternative to --prompt")
			fs.StringVar(&j.Out, "out", "", "output name or absolute path")
			fs.Var(&images, "image", "input/reference image; repeat for multiple images (uses edits endpoint)")
			fs.StringVar(&j.Mask, "mask", "", "PNG mask for local editing")
		}
	}
	if err := fs.Parse(argv[1:]); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return nil
		}
		return errors.New("invalid command options; run <command> --help")
	}
	if fs.NArg() != 0 {
		return errors.New("unexpected positional arguments; use --prompt-file for complex prompts")
	}
	if command == "config-init" {
		result, err := initConfig(opts.configPath)
		if err != nil {
			return err
		}
		return json.NewEncoder(output).Encode(result)
	}
	if seconds <= 0 || seconds > 1800 {
		return errors.New("timeout must be greater than zero and at most 1800 seconds")
	}
	opts.timeout = time.Duration(seconds * float64(time.Second))
	cfg, err := loadConfig(opts.configPath, opts.dryRun)
	if err != nil {
		return err
	}
	if command == "doctor" {
		result, err := doctor(cfg, opts.online, opts.timeout)
		if err != nil {
			return err
		}
		return json.NewEncoder(output).Encode(result)
	}
	if opts.attempts < 1 || opts.attempts > 5 {
		return errors.New("max-attempts must be between 1 and 5")
	}
	if j.Model == "" {
		j.Model = cfg.Model
	}
	if command == "generate-batch" {
		if opts.concurrency < 1 || opts.concurrency > 8 {
			return errors.New("concurrency must be between 1 and 8")
		}
		jobs, err := readBatch(opts.input)
		if err != nil {
			return err
		}
		items, err := prepareBatch(jobs, j, opts)
		if err != nil {
			return err
		}
		result, runErr := executeBatch(cfg, items, opts)
		if err := json.NewEncoder(output).Encode(result); err != nil {
			return err
		}
		return runErr
	}
	if (j.Prompt == "") == (opts.promptFile == "") {
		return errors.New("provide exactly one of --prompt or --prompt-file")
	}
	if opts.promptFile != "" {
		data, err := os.ReadFile(opts.promptFile)
		if err != nil {
			return errors.New("cannot read prompt file")
		}
		j.Prompt = strings.TrimPrefix(string(data), "\ufeff")
	}
	j.Images = images
	if command == "edit" && len(images) == 0 {
		return errors.New("edit requires at least one --image")
	}
	item, err := prepareJob(j, j, opts, 1)
	if err != nil {
		return err
	}
	result, err := execute(cfg, item, opts)
	if err != nil {
		return err
	}
	return json.NewEncoder(output).Encode(result)
}

func main() {
	if err := run(os.Args[1:], os.Stdout); err != nil {
		_ = json.NewEncoder(os.Stderr).Encode(map[string]string{"status": "error", "message": err.Error()})
		os.Exit(1)
	}
}
