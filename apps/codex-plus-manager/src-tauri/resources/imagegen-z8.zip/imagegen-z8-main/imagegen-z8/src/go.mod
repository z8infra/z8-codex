module imagegen-z8

go 1.23
