---
name: imagegen-z8
description: Generate or edit raster images through a user-configured OpenAI-compatible Image API. Use for imagegen-Z8 requests, relay/API image generation, reference-guided images, product shots, covers, illustrations, variants, background changes, compositing, and batches. Works in Codex and Claude Code with the bundled native executable; no SDK installation is needed. Prefer existing vector/code assets when the user wants deterministic SVG or code-native graphics.
metadata:
  version: "1.0.0"
---

# imagegen-Z8

Use this skill's bundled executable to generate and edit images through the user's configured image API. It is independent of the built-in image generator and does not require codex-image2 or z8-codex. Display name: **imagegen-Z8**; portable invocation identifier: **imagegen-z8**.

## Start here

1. Locate this skill's directory from the loaded `SKILL.md`; do not assume an agent-specific path.
2. Run the platform wrapper below. Do not compile code or install Python, Node.js, Go, or an SDK during normal use.
3. If configuration has not been checked in this session, run `doctor` (offline). See [configuration.md](references/configuration.md) for missing configuration. Never read the real `.env` into model context or ask for a key in chat.
4. Use `generate`, `edit`, or `generate-batch`; see [cli.md](references/cli.md) and [image-api.md](references/image-api.md).

Windows:

```powershell
& "<skill-dir>\scripts\imagegen-Z8.ps1" doctor
```

macOS / Linux:

```sh
sh "<skill-dir>/scripts/imagegen-Z8.sh" doctor
```

The executable loads credentials from `<user-home>/.imagegen-Z8/.env`, a complete set of `IMAGEGEN_*` process variables, or an explicit `--config` file. It does not reuse coding-provider credentials or read a project's `.env`.

Version 1 implements **direct API mode only**. `IMAGEGEN_MODE=z8` is reserved and reports an unsupported-mode error; do not claim one-click z8-codex integration exists yet.

## Decide intent and request shape

- No input image: `generate` uses `/images/generations`.
- New image guided by references: `generate --image ...` uses `/images/edits` as transport. Describe which aspects to borrow; do not assume the reference must remain unchanged.
- Changes to an existing image: `edit --image ...`. Inspect each input with the host's image viewer, then specify what changes and what stays unchanged.
- Multiple distinct assets: separate prompts or `generate-batch`. Use `--n` for variants of the same prompt only.
- Attachments must be available as local files. Use the host's supported attachment path/export mechanism. If no path is available, ask for an accessible file; never invent a path or pretend the image was sent.
- Keep originals. Follow-up edits also write to new paths.

## Workflow

1. Gather the prompt, intended use, exact text, constraints and image paths. Ask only for missing details that block the request.
2. Label each input by index and role: edit target, style/composition reference, or inserted subject.
3. Preserve detailed user prompts. For vague requests, add only useful composition, lighting or intended-use details; do not invent brands, slogans or unrelated objects.
4. Consult [prompting.md](references/prompting.md) for complex requests and [sample-prompts.md](references/sample-prompts.md) for relevant recipes, not mandatory additions.
5. Put complex prompts in a UTF-8 file and pass `--prompt-file`. For batches use [batch-format.md](references/batch-format.md).
6. Generate with the configured model. Do not silently switch providers or models to bypass errors.
7. Inspect saved outputs for subject, text accuracy, composition, requested changes and preserved details. API success does not establish visual correctness.
8. Refine with a targeted follow-up edit using the chosen output as input, repeating its invariants.
9. Show images inline when the host supports local-image rendering, using absolute paths; otherwise provide local file links. Report paths, a concise prompt/change summary and any unverified visual constraints.

## Prompt scaffolding

Use only relevant lines:

```text
Use case: <product-mockup, illustration-story, precise-object-edit, etc.>
Asset type: <where the image will be used>
Primary request: <the user's request>
Input images: <Image 1: role; Image 2: role>
Scene/backdrop: <environment>
Subject: <main subject>
Style/medium: <photo, illustration, 3D, etc.>
Composition/framing: <camera angle, crop, placement, negative space>
Lighting/mood: <lighting and mood>
Color palette: <only if relevant>
Text (verbatim): "<exact text>"
Constraints: <what to preserve or include>
Avoid: <what must not appear>
```

Quote image text verbatim. Repeat edit invariants each iteration. Image roles are prompt instructions, not separate API fields.

## Output and capability rules

- Finals default to `output/imagegen/` under the current workspace. Every relative `--out` resolves under `--out-dir`; use an absolute path for another destination.
- Existing files are rejected unless the user requested replacement and `--force` is set. Replacing an input image is always rejected.
- Save intermediate prompt/JSONL files under `tmp/imagegen/` when useful. Preserve user inputs.
- Models, sizes, quality, masks and transparency depend on the relay. The CLI validates basic request shape, not every provider's capabilities.
- For native transparency use PNG/WebP and `--background transparent` only with a provider/model known to support it. Check alpha with an available local inspection tool. White/checkerboard backgrounds are not proof of transparency. Never promise alpha or switch models silently.
- `doctor` checks local configuration; `doctor --online` additionally checks `/models`. Neither generates a test image or proves image-generation permission.
- `--dry-run` does not send requests, write images or require a key. Do not call it successful generation.
- Requests use one attempt by default. Timeouts are not resubmitted: the upstream job may have completed. Explain an uncertain result and let the user decide whether to resubmit. `--max-attempts` opts into retries for transient HTTP failures only.
- For authentication/permission errors, direct the user to update local configuration. Never print `.env`, credentials, Authorization headers or raw upstream error bodies.

## References

- [configuration.md](references/configuration.md): setup, precedence, credentials and reserved integration mode.
- [cli.md](references/cli.md): commands and single-image examples.
- [batch-format.md](references/batch-format.md): JSONL generation/edit jobs and partial failures.
- [image-api.md](references/image-api.md): endpoints, bodies and compatibility.
- [prompting.md](references/prompting.md): specificity, composition and invariants.
- [sample-prompts.md](references/sample-prompts.md): asset recipes adapted from the system skill.
