# imagegen-Z8

通过自选中转站生成、参考生图、编辑和批量生成图片的独立 skill，适用于 Codex 与 Claude Code。无需 Python、Node.js、Go 或 SDK。

- 显示名称：`imagegen-Z8`
- 机器调用标识：`imagegen-z8`（小写，兼容技能命名校验）
- 版本：`1.0.0`，独立 API 模式
- 配置：`<用户主目录>/.imagegen-Z8/.env`
- API：OpenAI 兼容 `/images/generations`、`/images/edits`

## 安装与使用

安装完整文件夹，必须带 `bin/`。宿主采用标准用户技能目录时，Codex 可用 `$CODEX_HOME/skills/imagegen-z8`，Claude Code 可用 `~/.claude/skills/imagegen-z8`；自定义路径以宿主设置为准。已用 Skills Manager 时，先纳入中央库再由 Preset 同步，避免重复复制。

Windows：

```powershell
& "<skill-dir>\scripts\imagegen-Z8.ps1" config-init
# 在本地编辑器填写命令返回的配置文件。
& "<skill-dir>\scripts\imagegen-Z8.ps1" doctor
& "<skill-dir>\scripts\imagegen-Z8.ps1" generate --prompt "一只坐在窗边的橘猫，温暖的水彩插画" --out "cat.png"
```

macOS/Linux：

```sh
sh "<skill-dir>/scripts/imagegen-Z8.sh" config-init
# 本地填写配置后：
sh "<skill-dir>/scripts/imagegen-Z8.sh" doctor
sh "<skill-dir>/scripts/imagegen-Z8.sh" generate --prompt "A cat by the window, warm watercolor" --out "cat.png"
```

也可在聊天中调用 `imagegen-z8` 描述需求。宿主支持技能快捷调用时，Codex 使用 `$imagegen-z8`，Claude Code 使用 `/imagegen-z8`。图片默认保存到当前工作目录的 `output/imagegen/`，可以继续作为改图输入。

`doctor` 默认离线；`doctor --online` 查询模型列表，不生图。`generate --dry-run` 无需真实 Key，不会出图。实际生图消耗所配置服务的额度。

## 文档

- [配置、优先级和排错](references/configuration.md)
- [CLI 和改图](references/cli.md)
- [批量 JSONL](references/batch-format.md)
- [API 兼容范围](references/image-api.md)
- [智能体工作流程](SKILL.md)

提供 Windows/macOS/Linux 的 x64、ARM64 程序。本次开发机器只能运行验证 Windows x64；其他平台完成交叉编译后仍需各平台运行验收。

更新替换技能包，包外配置不变。旧 codex-image2 凭据在本地手动迁移，不放进分发包。z8-codex 界面与一键配置留到下一阶段。

## 开发

`src/` 使用 Go 标准库，无第三方模块。运行 `go test ./...`、`go vet ./...` 后，使用 `scripts/build.ps1` 构建六个平台并更新 `bin/SHA256SUMS`。

提示词材料由系统 imagegen 副本适配，许可证见 [LICENSE.txt](LICENSE.txt)，修改说明见 [NOTICE](NOTICE)。
