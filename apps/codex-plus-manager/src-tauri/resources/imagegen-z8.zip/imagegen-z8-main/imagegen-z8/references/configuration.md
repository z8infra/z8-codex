# 配置与安装

imagegen-Z8 1.0 使用 OpenAI 兼容 Image API，可独立用于 Codex、Claude Code。机器调用标识为 `imagegen-z8`，显示名称为 `imagegen-Z8`。

## 首次配置

1. 安装完整 skill 包，包含 `bin/`，不要只复制 `SKILL.md`。宿主技能目录中直接包含该包，不要再套一层同名目录。
2. Windows：`& "<skill-dir>\scripts\imagegen-Z8.ps1" config-init`；macOS/Linux：`sh "<skill-dir>/scripts/imagegen-Z8.sh" config-init`。
3. 命令创建示例文件并返回绝对路径。用本地编辑器填写 Base URL、API Key、模型，不把真实内容发送到聊天中。
4. 运行 `doctor` 做离线检查；按需用 `doctor --online` 检查模型列表。
5. 在宿主中调用 `imagegen-z8`，描述图片需求。需要刷新技能列表或新建会话时按宿主提示操作。

默认路径：`<用户主目录>/.imagegen-Z8/.env`。`config-init` 不覆盖已有文件，不修改系统环境变量。POSIX 新目录/文件分别使用 0700/0600；Windows 继承用户目录的 ACL，应放个人用户目录而非共享目录。`.env` 是本地明文配置，不是加密凭据库。

```dotenv
IMAGEGEN_MODE=direct
IMAGEGEN_BASE_URL=https://your-relay.example/v1
IMAGEGEN_API_KEY=replace-with-your-key
IMAGEGEN_MODEL=gpt-image-2
```

替换示例地址和 Key。默认模型名不代表你的服务已经提供它。编程服务的 Responses 地址只有同时提供 Image API 时才能使用。

## 配置优先级

连接配置整组选取，不逐字段混合：

1. 命令的 `--config <文件>`。
2. `IMAGEGEN_CONFIG` 环境变量指定的文件。
3. 进程中的 `IMAGEGEN_MODE`、`IMAGEGEN_BASE_URL`、`IMAGEGEN_API_KEY`、`IMAGEGEN_MODEL`、`IMAGEGEN_KEY_ID`：出现任意一个时，这一组作为唯一来源；缺少地址/Key 就报错，不从文件补齐。
4. 默认用户配置文件。

`--model` 只覆盖本次请求模型；批量 job 的 `model` 再覆盖批量默认模型。缺省模型为 `gpt-image-2`。不读取 `CODEX_API_*`、`OPENAI_API_KEY`、`ANTHROPIC_API_KEY`、skill 或工作目录的 `.env`。

支持 UTF-8/BOM、CRLF、空行、`#` 注释、引号及可选 `export ` 前缀；不执行 shell、不替换变量、不解释反斜杠转义。重复或未知字段只报告行号。含空格或 `#` 的值建议用引号。

## Base URL

- 纯域名 `https://relay.example.net` 自动追加 `/v1`。
- 已有 `/v1` 或自定义 `/api/image/v2` 路径原样保留。
- 不接受完整 `/images/generations`、`/images/edits`、`/models` 端点。
- HTTPS；仅回环开发接口可用 HTTP。不允许用户名、密码、查询参数或片段。
- 没有隐含默认中转站，避免把 Key 发往未配置服务。

## 后续集成、更新与迁移

目前仅 `IMAGEGEN_MODE=direct`。`z8` 模式和 `IMAGEGEN_KEY_ID` 是保留字段，会明确报尚未支持，不改用其他凭据。z8-codex 管理界面、凭据引用和托管连接留到下一阶段。

更新只替换技能包，包外配置与项目图片保留。从 codex-image2 迁移时，在本地编辑器将 `CODEX_API_URL`、`CODEX_API_KEY` 填到新字段；不要让智能体读取真实旧配置，不把它打包。本机使用 Skills Manager 时，先入中央库，再通过 Preset 同步。

`doctor` 只验证本地配置；`doctor --online` 请求 `/models`，不生成图片。中转站可能不支持模型列表，这不能单独判定图片接口不可用。只有实际生成并检查图片后，才算生图验证。
