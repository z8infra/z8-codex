# CLI commands

Windows examples use PowerShell. On macOS/Linux use `sh "<skill-dir>/scripts/imagegen-Z8.sh"` with POSIX quoting. Matching `bin/imagegen-Z8-*` executables can also be invoked directly. No runtime dependencies are required.

## Configuration and diagnostics

```powershell
& "<skill-dir>\scripts\imagegen-Z8.ps1" config-init
& "<skill-dir>\scripts\imagegen-Z8.ps1" doctor
& "<skill-dir>\scripts\imagegen-Z8.ps1" doctor --online
& "<skill-dir>\scripts\imagegen-Z8.ps1" version
```

`--config <file>` is available after each command except `version`. `config-init --config <file>` creates a template without overwriting. See [configuration.md](configuration.md).

## Generate

```powershell
& "<skill-dir>\scripts\imagegen-Z8.ps1" generate --prompt "A blue ceramic mug, clean product photography, no lettering" --out "mug.png"
& "<skill-dir>\scripts\imagegen-Z8.ps1" generate --prompt-file "tmp/imagegen/hero.txt" --size 1536x1024 --quality high --out "hero.png"
& "<skill-dir>\scripts\imagegen-Z8.ps1" generate --prompt "A nebula in a glass bottle" --dry-run
```

Defaults: configured model (otherwise `gpt-image-2`), `1024x1024`, quality `auto`, PNG, one image, 180-second timeout, one HTTP attempt.

Relative `--out` always resolves under `--out-dir` (default `output/imagegen`). `--out mug.png` saves `output/imagegen/mug.png`; do not repeat the directory in both options. Absolute paths are used as given. Missing names get a timestamp and hash. `--n 2` adds `-1`, `-2` before the extension.

## References and edits

```powershell
& "<skill-dir>\scripts\imagegen-Z8.ps1" generate --image "input/style.png" --prompt "Create a mountain scene using Image 1 only as palette and brushwork reference" --out "mountains.png"
& "<skill-dir>\scripts\imagegen-Z8.ps1" edit --image "input/product.png" --prompt "Replace only the background. Preserve the product, label, proportions and edges." --out "product-edited.png"
& "<skill-dir>\scripts\imagegen-Z8.ps1" edit --image "input/scene.png" --image "input/subject.png" --prompt-file "tmp/imagegen/composite.txt" --out "composite.png"
```

With `--image`, both commands use edits. Repeat it for ordered inputs. One input uses multipart `image`; multiple inputs use `image[]`. `--mask mask.png` supplies a PNG mask. Provider limits and mask semantics remain authoritative. Inputs accept PNG/JPEG/WebP, up to 50 MiB each and 128 MiB combined.

## Controls

- `--model`: request-specific model.
- `--size`: `auto` or `WIDTHxHEIGHT`, subject to provider limits.
- `--quality`: `auto`, `low`, `medium`, `high`.
- `--output-format`: `png`, `jpeg`, `webp`; extension must match (`.jpg` also works for JPEG).
- `--background`: omitted by default; `auto`, `opaque`, `transparent` only when requested and supported.
- `--force`: explicitly replace outputs; never inputs.
- `--timeout`: seconds, greater than zero and at most 1800.
- `--max-attempts`: 1–5, default 1. Opt-in retries apply to HTTP 429/500/502/503/504/524. Network failures are not resubmitted because completion is uncertain.
- `--dry-run`: no network, images or key needed. Explicit malformed config still fails. Prints prompts, request shape and planned paths, never credentials.

## Return contract

Success returns JSON with absolute `outputs`, model, requested size/quality and format. Errors use stderr JSON `{ "status": "error", "message": "..." }` and exit code 1. No upstream error bodies/headers are exposed. See [batch-format.md](batch-format.md) for partial results.

Responses must contain `data[].b64_json` or `data[].url`. Downloads do not receive the API key. Bytes are checked for PNG/JPEG/WebP signatures and matching format, not full visual quality or alpha correctness.
