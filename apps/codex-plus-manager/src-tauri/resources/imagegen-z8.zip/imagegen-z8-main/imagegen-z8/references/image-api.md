# Image API compatibility contract

Version 1 implements OpenAI-compatible **Image API**, not Responses tools, Chat Completions image output, Gemini-native endpoints, async polling or vendor-specific authentication.

| Operation | Request |
|---|---|
| Generation | `POST <api-root>/images/generations`, JSON |
| Edit / reference-guided generation | `POST <api-root>/images/edits`, multipart |
| Optional check | `GET <api-root>/models` |

Authentication is `Authorization: Bearer <local key>`. API redirects are refused. Root paths are preserved; `/v1` is appended only for a URL without a path.

Fields: `model`, `prompt`, `size`, `quality`, `n`, `output_format`, optional `background`. Edit requests add `image` for one input, repeated `image[]` for multiple inputs, optional `mask`.

Responses: `data: [{b64_json: "..."}]` or `data: [{url: "https://..."}]`, exactly the requested image count. Job-ID/polling responses need a future adapter. Image URLs receive no upstream Authorization header; HTTPS signed URLs work. API responses are limited to 192 MiB, images/downloads to 50 MiB each.

Capabilities depend on the relay, model and key. `/models` listing does not prove image permission. The configured default `gpt-image-2` is a model identifier, not an availability promise. Exposed quality levels are `low`, `medium`, `high`, `auto`; dimensions are `auto` or a positive pixel pair. Provider validation remains authoritative.

`background=transparent` is sent only when requested, requires PNG/WebP locally and still needs provider support. Never silently switch models or fake alpha. `input_fidelity` is not sent by this version.

Errors omit upstream bodies, credentials and signed download URLs. For 400/422 responses, compare provider-supported options with the non-secret dry-run payload; only change optional settings when it preserves the user's request.
