# Batch JSONL

One JSON object per line; UTF-8, blank lines and `#` comment lines accepted. Maximum 500 jobs, 1 MiB per line. All jobs validate before any API calls.

```jsonl
{"prompt":"A blue mug on white","out":"mug.png"}
{"prompt":"A red kite in the sky","size":"1536x1024","quality":"low","n":2,"out":"kite.png"}
{"prompt":"Change only the background; preserve the label","images":["input/product.png"],"out":"product-edited.png"}
```

Fields: `prompt` (required), `model`, `size`, `quality`, `n`, `out`, `output_format`, `images` (local path array), `mask`. Unknown fields fail. `images` selects edits; otherwise generation. Input paths are relative to the current working directory, not the JSONL file. Relative outputs resolve under `--out-dir`.

```powershell
& "<skill-dir>\scripts\imagegen-Z8.ps1" generate-batch --input "tmp/imagegen/jobs.jsonl" --out-dir "output/imagegen" --concurrency 2
```

Job fields override CLI defaults. `--n` is variants per prompt. Use unique output names, including numbered variants. Colliding outputs and direct cross-job input/output overlaps fail before submission.

Concurrency is 1–8, default 2. `--fail-fast` stops new scheduling after failure; already-running jobs finish. Completed images survive another job's failure. JSON includes ordered job `index`, `status` (`succeeded`, `failed`, `skipped`), result/error and counts. Any failure exits 1; retry only intended unfinished jobs.

`--dry-run` validates offline without creating output files/directories.
